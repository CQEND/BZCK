urlpatterns = []  # type: ignore
